<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LikeAndDis extends Model
{
    //
}
