<?php $__env->startSection('title', 'репозетории'); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-12 myheader">
        <input type="text" class="search_word">
        <button class="search_repos">Искать</button>
        <button class="show_all_repos">Показать все</button>
        <input type="hidden" class="user_name" value="<?php echo e($authorized_user); ?>">
        <input type="hidden" class="cur_user" value="<?php echo e($current_user); ?>">
    </div>

    <div class="loader">
        <img src="<?php echo e(asset('img/loading.gif')); ?>" class="ajaxLoader">
    </div>
        <div class="all_repos">
         <?php $__currentLoopData = $repositories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12 reposit_st">
            <div class="author_info">
                <img src="<?php echo e($repos->owner->avatar_url); ?>" alt="" class="avatar">
                <h4><?php echo e($repos->owner->login); ?></h4>
            </div>
            <h3 data-url_repo="<?php echo e($repos->url); ?>" class="repos_name"><?php echo e($repos->name); ?></h3>
            <span><?php if($repos->description): ?>
                    <?php echo e($repos->description); ?>

                  <?php else: ?> Нету описания! <?php endif; ?>
            </span>
            <?php if(isset($repos->deslike) && $repos->deslike !=1): ?>
            <i class="fa fa-thumbs-down <?php if(isset($repos->like) && $repos->like !=1): ?> lp_hidden active_deslike <?php endif; ?> dislike_repos" data-id="<?php echo e($repos->id); ?>" data-id_author="<?php echo e($current_user); ?>"></i>
            <i class="fa fa-heart like_repos <?php if(isset($repos->like) && $repos->like ==1): ?> lp_hidden active_like <?php endif; ?>" data-id="<?php echo e($repos->id); ?>" data-id_author="<?php echo e($current_user); ?>"></i>
            <?php endif; ?>
        </div>
             <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>