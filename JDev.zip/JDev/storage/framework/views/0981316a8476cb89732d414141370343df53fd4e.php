<?php $__env->startSection('title', 'Авторизация'); ?>

<?php $__env->startSection('content'); ?>
    <div class="login_container">
    <div class="title m-b-md">
        gitHub
    </div>
    <?php if($access_token != ''): ?>
        <p>Logged in</p>
    <?php else: ?>
        <a href="https://github.com/login/oauth/authorize?client_id=<?php echo e($client_id); ?>">
                <button type="button" class="btn btn-primary authorization">Авторизация</button>
            </a>
    <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>